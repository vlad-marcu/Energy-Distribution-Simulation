public abstract class Participant {
    /**
     * updates a participant
     */
    public abstract void update();
}
